//
//  todoCell.swift
//  ToDoTimer
//
//  Created by Young, Justin (jyoung51) on 12/3/19.
//  Copyright © 2019 Young, Justin (jyoung51). All rights reserved.
//

import UIKit

class todoCell: UITableViewCell {

    @IBOutlet weak var TomatoImage: UIImageView!
    @IBOutlet weak var ToDoLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    var isChecked = false

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
