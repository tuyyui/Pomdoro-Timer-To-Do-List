//
//  DataToDo2ViewController.swift
//  ToDoTimer
//
//  Created by Young, Justin (jyoung51) on 12/3/19.
//  Copyright © 2019 Young, Justin (jyoung51). All rights reserved.
//

import UIKit

class DataToDo2ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var count : Int = 0
    
    @IBOutlet weak var TodoTableView: UITableView!
    
    var Todos: [String] = ["Sample"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        TodoTableView.delegate = self
        TodoTableView.dataSource = self
        TodoTableView.rowHeight = 80
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func addToDo(_ sender: Any) {
        let TodoAlert = UIAlertController(title: "Add a Task", message: "Add a new task", preferredStyle: .alert)
        TodoAlert.addTextField()
        
        let addtodoAction = UIAlertAction(title: "Add", style: .default) { (action) in
            let newTodo = TodoAlert.textFields![0]
            self.Todos.append(newTodo.text!)
            self.TodoTableView.reloadData()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .default)
        TodoAlert.addAction(addtodoAction)
        TodoAlert.addAction(cancelAction)
        
        present(TodoAlert, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Todos.count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "todoCell", for: indexPath) as! todoCell
        cell.ToDoLabel.text = Todos[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as! todoCell
        
        if cell.isChecked == false{
            count += 1
            if count == 1 {
            cell.TomatoImage.image = UIImage(named: "rush-14.png")
            cell.isChecked = false
                
            }
            else if count == 2 {
                cell.TomatoImage.image = UIImage(named: "star.jpg")
                cell.isChecked = true
            }
        } else{
            cell.TomatoImage.image = nil
            cell.isChecked = false
        }
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            Todos.remove(at: indexPath.row)
            TodoTableView.reloadData()
        }
    }
      /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
